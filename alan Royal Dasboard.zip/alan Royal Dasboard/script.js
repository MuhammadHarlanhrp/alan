function home(){
    document.getElementById('selamat').innerHTML="Selamat Datang, Nama Mahasiswa Kelas SI-3X";
}

function mahasiswa () {
    document.getElementById('selamat').innerHTML="Selamat Datang, HARLAN HARAHAP";
}

function kelas() {
    document.getElementById('selamat').innerHTML="Selamat Datang, HARLAN HARAHAP Kelas SI-3D";
}

function singout(){
    document.getElementById('selamat').innerHTML="Selamat Datang, Nama Mahasiswa Kelas";
}
